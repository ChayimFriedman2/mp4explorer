﻿//===============================================================================
// Copyright © 2009 CM Streaming Technologies.
// All rights reserved.
// http://www.cmstream.net
//===============================================================================

using CMStream.Mp4;

namespace Mp4Explorer
{
    /// <summary>
    /// 
    /// </summary>
    public interface IBoxView
    {
        /// <summary>
        /// 
        /// </summary>
        Mp4Box Box { get; set; }
    }
}
