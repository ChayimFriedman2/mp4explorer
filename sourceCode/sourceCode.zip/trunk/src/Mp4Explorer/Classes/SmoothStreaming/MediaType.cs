﻿//===============================================================================
// Copyright © 2009 CM Streaming Technologies.
// All rights reserved.
// http://www.cmstream.net
//===============================================================================

namespace Mp4Explorer.SmoothStreaming
{
    /// <summary>
    /// 
    /// </summary>
    public enum MediaType
    {
        /// <summary>
        /// 
        /// </summary>
        Video,

        /// <summary>
        /// 
        /// </summary>
        Audio,

        /// <summary>
        /// 
        /// </summary>
        Unknown
    }
}
