**Overview**

Tool to inspect and see in details a mp4 file.

This program can be used to extract all the boxes (box was called ‘atom’ in some specifications, including the first definition of MP4) of information, metadata and data from a MPEG-4 iso file (ISO/IEC 14496-12, ISO/IEC 14496-14, ISO/IEC 14496-15).

Our main goal, is provide as much information as possible inside a clear and easy to use windows application. For that, we need to provide a custom view (see [CompositeWPF](http://compositewpf.codeplex.com)) for each box type.

In the furture this program will permit a video preview and a low level edition.

This effort can help anyone who is developing multimedia and content generation programs.

We support a set of fragmented movie boxes and that means that you can read Smooth Streaming files(*.ismv).

More information in [CM Streaming Technologies Blog](http://blog.cmstream.net)

The screenshot for a video sample
![](Home_screenshot_51024.gif)

Browse the [source code](http://mp4explorer.codeplex.com/SourceControl/ListDownloadableCommits.aspx)